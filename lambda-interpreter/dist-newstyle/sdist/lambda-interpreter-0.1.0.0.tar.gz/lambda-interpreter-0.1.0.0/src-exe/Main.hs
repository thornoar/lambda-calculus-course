module Main where

import Lambda
import System.IO
import System.Console.Haskeline

data Mode = REDUCE | REDUCESTEPS | PRINT | SHOW deriving (Read, Show)

-- Main executable

read_ :: Mode -> IO String
read_ mode = putStr ((show mode) ++ "> ")
  >> hFlush stdout
  >> getLine

eval_ :: Mode -> String -> String
eval_ _ "" = ""
eval_ REDUCE str = unparse' . reduce . parse' $ str
eval_ REDUCESTEPS str = unparse' . reduceTimes 1 . parse' $ str
eval_ PRINT str = unparse' . parse' $ str
eval_ SHOW str = show . parse' $ str

print_ :: Mode -> String -> IO ()
print_ _ = putStrLn

-- prompt :: String -> IO ()
-- prompt = putStr . (++ "> ")

loop_ :: Mode -> IO ()
loop_ mode = do
  input <- read_ mode
  case input of
    ":quit" -> putStrLn "exiting..."
    ":help" -> do
      help
      loop_ mode
    _ -> do
      print_ mode (eval_ mode input) >> loop_ mode

help :: IO ()
help = do
  putStrLn "cannot help you"

main = loop_ REDUCE
